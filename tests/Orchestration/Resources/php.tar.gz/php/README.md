If you do changes to confent of this folder, run following command inside `Resources` directory:

```sh
tar -zcf ./php.tar.gz php
```