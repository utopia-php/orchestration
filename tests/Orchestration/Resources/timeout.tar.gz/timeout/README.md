If you do changes to confent of this folder, run following command inside `Resources` directory:

```sh
tar -zcf ./timeout.tar.gz timeout
```