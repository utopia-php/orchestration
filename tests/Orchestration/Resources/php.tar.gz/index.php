<?php

echo 'Hello World! ' . $_ENV["test"];
